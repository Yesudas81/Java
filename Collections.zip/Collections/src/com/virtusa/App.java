package com.virtusa;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.TreeSet;

import javax.naming.ldap.SortControl;

public class App {
    public static void main(String[] args) throws Exception {
        Emp e1=new Emp(1,"sampath",55000.0);
        Emp e2=new Emp(2,"surya",30000.0);
        Emp e3=new Emp(3,"rooppa",25000.0);
        Emp e4=new Emp(4,"ajay",45000.0);
        Emp e5=new Emp(5,"ravi",35000.0);

        ArrayList<Emp> al=new ArrayList<>();
        al.add(e1);
        al.add(e2);
        al.add(e3);
        al.add(e4);
        al.add(e5);
        Collections.sort(al);

        for(Emp e:al)
        {
            System.out.println(e.getEid()+" "+e.getEname()+" "+e.getEsal());
        }
        
    }
}
/*
 * al1=10 11 10 13 14 13
 * al2=20 14 25 26 12 10
 * 10 11 12 13 14 20 25 26
 * Hint: removeAll or retainAll or conatains
 */