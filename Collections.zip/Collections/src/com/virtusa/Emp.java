package com.virtusa;

import java.util.Comparator;

public class Emp implements Comparable<Emp>{
    private int eid;
    private String ename;
    private double esal;

    public Emp(int eid, String ename, double esal) {
        this.eid = eid;
        this.ename = ename;
        this.esal = esal;
    }

    public Emp() {
    }

    public int getEid() {
        return eid;
    }


    public void setEid(int eid) {
        this.eid = eid;
    }


    public String getEname() {
        return ename;
    }


    public void setEname(String ename) {
        this.ename = ename;
    }


    public double getEsal() {
        return esal;
    }


    public void setEsal(double esal) {
        this.esal = esal;
    }


    @Override
    public String toString() {
        return "Emp [eid=" + eid + ", ename=" + ename + ", esal=" + esal + "]";
    }

    /* (non-Javadoc)
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(Emp e) {
            return ename.compareTo(e.ename);
    }

    
    // public int compare(Emp e1, Emp e2) {
    //     return e2.ename.compareTo(e1.ename);
    // }
    
}
